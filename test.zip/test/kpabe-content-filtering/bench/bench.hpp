/**
 * @file bench.hpp
 * @author your name (you@domain.com)
 * @brief 
 * @version 0.1
 * @date 2023-09-27
 * 
 * @copyright Copyright (c) 2023
 * 
 */

#ifndef __BENCH_HPP__
#define __BENCH_HPP__

#include <unistd.h>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>

#include "../kpabe/kpabe.hpp"


#endif // __BENCH_HPP__
